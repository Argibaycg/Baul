﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    public class Estante
    {
        private int ubicacionEstante;
        private Producto[] productos;

        private Estante(int capacidad)
        {
            this.productos = new Producto[capacidad];
        }

        public Estante(int capacidad, int ubicacion) : this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }
        public Producto[] GetProductos()
        {
            return this.productos;
        }

        public static string MostrarEstante(Estante estante)
        {
            string cadena = string.Empty;

            foreach (Producto auxProducto in estante.GetProductos())
            {
                if (!(auxProducto is null))
                {
                    cadena += estante.ubicacionEstante + " " +
                              Producto.MostrarProducto(auxProducto) + "\n";
                }
            }
            return cadena;
        }

        //public static bool operator ==(Estante estante, Producto producto)
        //{
        //    bool existe = false;

        //    foreach (Producto auxProducto in estante.GetProductos())
        //    {
        //        if (!(auxProducto is null))
        //        {
        //            if(auxProducto == producto)
        //            {
        //                existe = true;
        //            }
        //        }
        //    }

        //    return existe;
        //}

        public static bool operator ==(Estante estante, Producto producto)
        {
            return estante.productos.Contains(producto);
        }

        public static bool operator !=(Estante estante, Producto producto)
        {
            return !(estante == producto);
        }

        public static bool operator +(Estante estante, Producto producto)
        {
            bool agregado = false;
            if (estante != producto)
            {
                Producto[] auxArray = estante.GetProductos();

                for (int i = 0; i < auxArray.Length; i++)
                {
                    if (auxArray[i] is null)
                    {
                        auxArray[i] = producto;
                        agregado = true;
                        break;
                    }
                }
            }

            return agregado;
        }

        public static Estante operator -(Estante estante, Producto producto)
        {
            if (estante == producto)
            {
                for (int i = 0; i < estante.productos.Length; i++)
                {
                    if (estante.productos[i] == producto)
                    {
                        estante.productos[i] = null;
                        break;
                    }
                }
            }

            return estante;
        }

        //public static bool operator /(Estante e, Producto p)
        //{
        //    bool flag = false;

        //    if (e != p)
        //    {
        //        for (int i = 0; i < e.productos.Length; i++)
        //        {
        //            if (e.productos[i] is null)
        //            {
        //                e.productos[i] = p;
        //                flag = true;
        //                break;
        //            }
        //        }
        //    }

        //    return flag;
        //}
    }
}
