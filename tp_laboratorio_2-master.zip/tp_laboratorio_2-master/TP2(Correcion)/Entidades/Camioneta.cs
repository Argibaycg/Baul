﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Camioneta : Vehiculo
    {
        /// <summary>
        /// Constructor de la clase camioneta que llama al constructor base vehiculo
        /// </summary>
        /// <param name="marca">marca de la camioneta</param>
        /// <param name="chasis">chasis de la camioneta</param>
        /// <param name="color">color de la camioneta</param>
        public Camioneta(EMarca marca, string chasis, ConsoleColor color) :base(chasis, marca, color)
        {
        }

        /// <summary>
        /// Retorna el tamaño de la camioneta
        /// </summary>
        protected override ETamanio Tamanio
        {
            get
            {
                return ETamanio.Grande;
            }
        }

        /// <summary>
        /// Muestra los atributos de la camioneta y llama al metodo base
        /// </summary>
        /// <returns>Retorna los atributos de la camioneta</returns>
        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("CAMIONETA");
            sb.AppendLine(base.Mostrar());
            sb.AppendFormat("TAMAÑO : {0}", this.Tamanio);
            sb.AppendLine("");
            sb.AppendLine("---------------------");

            return sb.ToString();
        }
    }
}
