﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCinco
{
    class Program
    {
        static void Main(string[] args)
        {
            int input;
            int total = 0;
            int center;

            Console.Write("Ingrese un numero: ");
            string aux = Console.ReadLine();
            int.TryParse(aux, out input);

            for (int i = 1; i <= input; i++)
            {
                total += i;
                Console.WriteLine(total);
            }

            total = total / 2;

            do
            {

                center = input + (input - 1);

            } while (input >= total);

            Console.WriteLine("El centro es: {0}",center);

            Console.ReadKey();

        }
    }
}
