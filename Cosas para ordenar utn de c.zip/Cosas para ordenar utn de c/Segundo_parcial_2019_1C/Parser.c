#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Empleado.h"

int parser_parseEmpleados(char* fileName, LinkedList* listaEmpleados)
{
	int retorno = -1;
	int cantidadLeida;
	int index = 0;
	char id[1024],nombre[1024],horasTrabajadas[1024];
	Empleado* pEmpleado;
	FILE *archivo;

	archivo = fopen(fileName,"r");

	if(listaEmpleados != NULL && archivo != NULL)
	{
		cantidadLeida = fscanf(archivo, "%[^,],%[^,],%[^\n]\n",id,nombre,horasTrabajadas);

		do {
				cantidadLeida = fscanf(archivo, "%[^,],%[^,],%[^\n]\n",id,nombre,horasTrabajadas);
				if (cantidadLeida == 3)
				{
					pEmpleado = ll_get(listaEmpleados,index);
					if(pEmpleado != NULL)
					{
						pEmpleado->id = atoi(id);
						strcpy(nombre,pEmpleado->nombre);
						pEmpleado->horasTrabajadas = atoi(horasTrabajadas);
						index++;
					}
					ll_add(listaEmpleados,pEmpleado);
					retorno = 1;
				}else
				{
					retorno = -1;
					break;
				}
			} while (!feof(archivo));
	}
		fclose(archivo);
		return retorno;
}
