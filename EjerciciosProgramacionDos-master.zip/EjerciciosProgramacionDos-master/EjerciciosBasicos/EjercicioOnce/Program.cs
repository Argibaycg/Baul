﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioOnce
{
    class Program
    {
        static void Main(string[] args)
        {
            int input;
            int total = 0;
            int max = default;
            int min = default;
            int i = 0;

            for (; i < 10; i++)
            {
                Console.Write("Ingrese un numero: ");
                string aux = Console.ReadLine();
                int.TryParse(aux, out input);

                if (Validacion.Validar(input, -100, 100))
                {
                    total += input;

                    if (i == 0)
                    {
                        max = input;
                        min = input;
                    }
                    else if (input > max)
                    {
                        max = input;
                    }
                    else if (input < min)
                    {
                        min = input;
                    }
                }
                else
                {
                    Console.WriteLine("Ese numero no esta dentro del rango.");
                }
            }

            Console.WriteLine("El mayor es: {0}", max);
            Console.WriteLine("El menor es: {0}", min);
            Console.WriteLine("El promedio es: {0}", total / i);
            
            Console.ReadKey();


        }
    }
}
