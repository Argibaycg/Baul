﻿using ClasesAbstractas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesInstanciables
{
    public sealed class Profesor : Universitario
    {
        private Queue<Universidad.EClases> clasesDelDia;
        private static Random random;

        #region Constructores
        /// <summary>
        /// Constructor estatico que instancia el atributo Random
        /// </summary>
        static Profesor()
        {
            random = new Random();
        }
        
        /// <summary>
        /// Constructor publico que instancia la lista de clases y llama al metodo que asigna clases random a los profesores
        /// </summary>
        public Profesor() :base()
        {
            this.clasesDelDia = new Queue<Universidad.EClases>();
            _randomClases();
            _randomClases();
        }

        /// <summary>
        /// Constructor publico que instancia la lista de clases y llama al metodo que asigna clases random a los profesores
        /// </summary>
        /// <param name="id">ID</param>
        /// <param name="nombre">Nombre</param>
        /// <param name="apellido">Apellido</param>
        /// <param name="dni">DNI</param>
        /// <param name="nacionalidad">Nacionalidad</param>
        public Profesor(int id,string nombre, string apellido, string dni, ENacionalidad nacionalidad) :base(id,nombre,apellido,dni,nacionalidad)
        {
            this.clasesDelDia = new Queue<Universidad.EClases>();
            _randomClases();
            _randomClases();
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Metodo que asigna clase al azar al profesor
        /// </summary>
        private void _randomClases()
        {
            Universidad.EClases clase = (Universidad.EClases)random.Next(0, 3);
            clasesDelDia.Enqueue(clase);
        }

        /// <summary>
        /// Metodo que muestras las clases del profesor
        /// </summary>
        /// <returns>Retorna la cadena "CLASES DEL DÍA" junto al nombre de la clases que da</returns>
        protected override string ParticiparEnClase()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CLASES DEL DIA: ");
            foreach (Universidad.EClases clase in this.clasesDelDia)
            {
                sb.AppendLine(clase.ToString());
            }
            return sb.ToString();
        }

        /// <summary>
        /// Sobreescritura del metodo mostrar datos
        /// </summary>
        /// <returns>Retorna los datos del profesor</returns>
        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("{0}\n", base.MostrarDatos());
            sb.AppendFormat("{0}\n", this.ParticiparEnClase());

            return sb.ToString();
        }

        /// <summary>
        /// Sobrecarga de ToString
        /// </summary>
        /// <returns>Hara publicos los datos del profesor</returns>
        public override string ToString()
        {
            return this.MostrarDatos();
        }
        #endregion

        #region Operadores
        /// <summary>
        /// Sobrecarga para comparar un profesor con una clase de universidad
        /// </summary>
        /// <param name="i">profesor</param>
        /// <param name="clase">clase</param>
        /// <returns>Retornara true si da esa clase</returns>
        public static bool operator ==(Profesor i, Universidad.EClases clase)
        {
           return i.clasesDelDia.Contains(clase);
        }

        /// <summary>
        /// Sobrecarga de !=
        /// </summary>
        /// <param name="i">profesor</param>
        /// <param name="clase">Clase de universidad</param>
        /// <returns>Niega el retorno dle operador ==</returns>
        public static bool operator !=(Profesor i, Universidad.EClases clase)
        {
            return !(i == clase);
        }
        #endregion
    }
}
