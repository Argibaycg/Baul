﻿using Archivos;
using Excepciones;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesInstanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private Universidad.EClases clase;
        private Profesor instructor;

        #region Propiedades
        public List<Alumno> Alumnos { get { return this.alumnos; } set { this.alumnos = value; } }
        public Universidad.EClases Clase { get { return this.clase; } set { this.clase = value; } }
        public Profesor Instructor { get { return this.instructor; } set { this.instructor = value; } }
        #endregion

        #region Constructores
        /// <summary>
        /// COnstructor por defecto
        /// </summary>
        private Jornada()
        {
            alumnos = new List<Alumno>();
        }

        /// <summary>
        /// COnstructor con parametros
        /// </summary>
        /// <param name="clase">clase</param>
        /// <param name="instructor">profesor</param>
        public Jornada(Universidad.EClases clase, Profesor instructor) : this()
        {
            this.Instructor = instructor;
            this.Clase = clase;
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Metodo para guardar la jornada
        /// </summary>
        /// <param name="jornada">jornada a guardar</param>
        /// <returns>Retorna true si pudo guardar la jornada</returns>
        public static bool Guardar(Jornada jornada) 
        {
            Texto txt = new Texto();
            return txt.Guardar(string.Format("{0}\\Jornada.txt", Environment.GetFolderPath(Environment.SpecialFolder.Desktop)), jornada.ToString());
        }

        /// <summary>
        /// Metodo para leer un archivo de texto de la jornada
        /// </summary>
        /// <returns>retorna los datos de la jornada</returns>
        public static string Leer() 
        {
            Texto txt = new Texto();
            string datos = string.Empty;
            
            txt.Leer(string.Format("{0}\\Jornada.txt", Environment.GetFolderPath(Environment.SpecialFolder.Desktop)), out datos);
            
            return datos;

        }

        /// <summary>
        /// Sobrecarga del metodo ToString
        /// </summary>
        /// <returns>Retorna los datos de la Jornada</returns>
        public override string ToString()
        {
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("JORNADA:");
                sb.AppendFormat("CLASE DE {0}: ", this.clase.ToString());
                sb.AppendFormat("POR {0}\n", this.instructor.ToString());
                sb.AppendLine("ALUMNOS:");
                foreach (Alumno alumno in this.alumnos)
                {
                    sb.AppendLine(alumno.ToString());
                }

                return sb.ToString();
            }
        }
        #endregion

        #region Operadores
        /// <summary>
        /// Sobrecarga de == para comparar jornadas y alumnos
        /// </summary>
        /// <param name="j">jornada</param>
        /// <param name="a">alumno</param>
        /// <returns>True si el alumno particpa de la jornada</returns>
        public static bool operator ==(Jornada j, Alumno a)
        {
            if (j.Alumnos.Contains(a))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Sobrecarga del operador !=
        /// </summary>
        /// <param name="j">jornada</param>
        /// <param name="a">alumno</param>
        /// <returns>Niega el retorno de la sobrecarga de ==</returns>
        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        /// <summary>
        /// Sobrecarga del operador + apara agregar alumnos a la jornada
        /// </summary>
        /// <param name="j">jornada</param>
        /// <param name="a">alumno</param>
        /// <returns>retorna el alumno agregado a la jornada o lanza AlumnoRepetidoException</returns>
        public static Jornada operator +(Jornada j, Alumno a)
        {
            if (j != a)
            {
                j.Alumnos.Add(a);
                return j;
            }
            throw new AlumnoRepetidoException();
        }
        #endregion
    }
}
