
#include <stdio.h>
#include <stdlib.h>

int main(void) {

	FILE* file = fopen("archivo.txt","w");
	if(file!=NULL)
	{
		printf("Abrio\n");
		char data[6];
		data[0]='H';
		data[1]='o';
		data[2]='l';
		data[3]='a';
		data[4]='\n';
		data[5]='0';

		fwrite(data,sizeof(char),5,file);
		fclose(file);

		int i = 456984;
		fwrite(&i,sizeof(int),1,file);
		fprintf(file,"%d",i);
		fclose(file);

		file = fopen("archivo.txt","r");
		if(file!=NULL)
		{
			int  i;
			fread(&i,sizeof(int),1,file);
			fclose(file);
			printf("lei la variable %d",i);
		}
	}


	return 0;
}
