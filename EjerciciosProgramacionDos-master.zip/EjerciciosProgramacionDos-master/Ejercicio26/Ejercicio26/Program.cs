﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio26
{
    class Program
    {
        static void Main(string[] args)
        {
			{
				Random numeroRandom = new Random();
				int[] array = new int[20];
				for (int i = 0; i < 20; i++)
				{
					array[i] = numeroRandom.Next(-100, 100);
				}

				Console.WriteLine("Array como fue ingresando:");
				foreach (int numero in array)
				{
					Console.Write("{0}, ", numero);
				}
				Console.WriteLine("\n");

				Array.Sort(array);

				Console.WriteLine("Numeros positivos ordenados de forma decreciente");
				for (int i = 19; i >= 0; i--)
				{
					if (array[i] >= 0)
					{
						Console.Write("{0}, ", array[i]);
					}
				}
				Console.WriteLine("\n");

				Console.WriteLine("Numeros negativos ordenados de forma creciente:");
				
				foreach (int numero in array)
				{
					if(numero < 0)
					{
						Console.Write("{0}, ", numero);
					}
				}
				Console.WriteLine("\n");




				Console.ReadKey();
			}
		}
    }
}
