﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstractas
{
    public abstract class Universitario : Persona
    {
        private int legajo;

        /// <summary>
        /// Constructor por defecto
        /// </summary>
        #region Constructores
        public Universitario() : base()
        {
            this.legajo = default;
        }

        /// <summary>
        /// Constructor que recibe parametros
        /// </summary>
        /// <param name="legajo">Lejago del universitario</param>
        /// <param name="nombre">Nombre del universitario</param>
        /// <param name="apellido">Apellido del universitario</param>
        /// <param name="dni">DNI del universitario</param>
        /// <param name="nacionalidad">Nacionalidad del universitario</param>
        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(nombre, apellido, dni, nacionalidad)
        {
            this.legajo = legajo;
        }

        /// <summary>
        /// Metodo para mostrar datos del Universitario
        /// </summary>
        /// <returns>Los datos del Universitario</returns>
        protected virtual string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("{0}\n",base.ToString());
            sb.AppendFormat("LEGAJO NUMERO: {0}\n",this.legajo);

            return sb.ToString();
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Firma del metodo abstracto participar en clase
        /// </summary>
        /// <returns>Retornara un string cuando sea implementado</returns>
        protected abstract string ParticiparEnClase();
        #endregion

        #region Operadores
        /// <summary>
        /// Sobrecarga del operador ==
        /// </summary>
        /// <param name="universitarioUno">Univeristario</param>
        /// <param name="universitarioDos">Universitario</param>
        /// <returns>Retornara true si y sólo si son del mismo Tipo y su Legajo o DNI son iguales</returns>
        public static bool operator ==(Universitario universitarioUno, Universitario universitarioDos)
        {
            if(universitarioUno.Equals(universitarioDos) && (universitarioUno.legajo == universitarioDos.legajo || universitarioUno.DNI == universitarioDos.DNI))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Sobrecarga del operador !==
        /// </summary>
        /// <param name="universitarioUno">Univeristario</param>
        /// <param name="universitarioDos">Univeristario</param>
        /// <returns>Niega la sobrecarga de == reutilizando codigo</returns>
        public static bool operator !=(Universitario universitarioUno, Universitario universitarioDos)
        {
            return !(universitarioUno == universitarioDos);
        }

       /// <summary>
       /// Sobrecarga del metodo Equals para comparar universitarios
       /// </summary>
       /// <param name="obj">Objeto</param>
       /// <returns>Retorna true si el objeto casteado a universitario comparten legajo y dni</returns>
        public override bool Equals(object obj)
        {
            if (obj is Universitario)
            {
                if ((this.legajo == ((Universitario)obj).legajo || this.DNI == ((Universitario)obj).DNI))
                    return true;
            }
            return false;
        }
        #endregion
    }
}
