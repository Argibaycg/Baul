﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio29
{
    class Program
    {
        static void Main(string[] args)
        {
            Equipo boquitaElMasGrande = new Equipo(1, "Bokee");

            Jugador riquelme = new Jugador(20123123, "Riquelme", 100, 50);
            Jugador palermo = new Jugador(30123123, "Palermo", 300, 50);

            if (boquitaElMasGrande + riquelme)
            {
                Console.WriteLine(riquelme.MostrarDatos());
            }

            if (boquitaElMasGrande + palermo)
            {
                Console.WriteLine(palermo.MostrarDatos());
            }
            else
            {
                Console.WriteLine("No se agregó a" + palermo.MostrarDatos());
            }

            Console.ReadKey();


        }
    }
}
