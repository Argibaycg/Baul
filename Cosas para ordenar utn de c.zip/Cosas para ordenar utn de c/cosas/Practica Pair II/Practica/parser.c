#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Cliente.h"


int parserEmployee(char* path , ArrayList* pArrayListEmployee);
{

}
