﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class DniInvalidoException : Exception
    {
        /// <summary>
        /// Constructor con mensaje por defecto
        /// </summary>
        public DniInvalidoException() : this("El DNI ingresado es invalido")
        {

        }
        /// <summary>
        /// Constructor que recibe mensaje por parametro
        /// </summary>
        /// <param name="message">Mensaje</param>
        public DniInvalidoException(string message) : base(message)
        {

        }

        /// <summary>
        /// COnstructor que recibe excepcion por parametro y tiene mensaje por defecto
        /// </summary>
        /// <param name="e">Exception</param>
        public DniInvalidoException(Exception e) : this("El DNI ingresado es invalido", e)
        {

        }

        /// <summary>
        ///Constructor que recibe mensaje y excepcion 
        /// </summary>
        /// <param name="message">Mensaje</param>
        /// <param name="e">Exception</param>
        public DniInvalidoException(string message, Exception e) : base(message, e)
        {

        }
    }
}
