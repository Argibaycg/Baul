﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClasesInstanciables;
using Excepciones;
using System.Collections.Generic;
using EntidadesAbstractas = ClasesAbstractas;

namespace TestUnitarios
{
    [TestClass]
    public class TestUnitarios
    {
        [TestMethod]
        public void TestListaAlumnosInstanciadaEnUniversidad()
        {
            //Arrange
            Universidad universidad;
            //Act
            universidad = new Universidad();
            //Assert
            Assert.IsInstanceOfType(universidad.Alumnos, typeof(List<Alumno>));
        }

        [TestMethod]
        public void TestListaJornadaInstanciadaEnUniversidad()
        {
            //Arrange
            Universidad universidad;
            //Act
            universidad = new Universidad();
            //Assert
            Assert.IsInstanceOfType(universidad.Jornadas, typeof(List<Jornada>));
        }

        [TestMethod]
        public void TestListaProfesoresInstanciadaEnUniversidad()
        {
            //Arrange
            Universidad universidad;
            //Act
            universidad = new Universidad();
            //Assert
            Assert.IsInstanceOfType(universidad.Instructores, typeof(List<Profesor>));
        }

        [TestMethod]
        public void TestColaInstanciadaEnProfesorInstanciadaEnUniversidad()
        {
            //Arrange
            Profesor davilaElMejor;
            //Act
            davilaElMejor = new Profesor();
            //Assert
            Assert.IsTrue(davilaElMejor == Universidad.EClases.Laboratorio || davilaElMejor != Universidad.EClases.Laboratorio);
        }

        [TestMethod]
        [ExpectedException(typeof(AlumnoRepetidoException))]
        public void TestAlumnoRepetidoException()
        {
            //Arrange
            Universidad universidad;

            Alumno alumnoUno;
            Alumno alumnoDos;
            //Act
            universidad = new Universidad();

            alumnoUno = new Alumno(1, "Juan", "Lopez", "12234456",
            EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
            Alumno.EEstadoCuenta.Becado);

            alumnoDos = new Alumno(1, "Juan", "Lopez", "12234456",
            EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
            Alumno.EEstadoCuenta.Becado);
            
            universidad += alumnoUno;
            universidad += alumnoDos;
        }

        [TestMethod]
        [ExpectedException(typeof(DniInvalidoException))]
        public void TestDniInvalidoException()
        {
            //Arrange
            Universidad universidad;
            Alumno alumnoUno;
            //Act
            universidad = new Universidad();

            alumnoUno = new Alumno(1, "Juan", "Lopez", "33564876",
            EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
            Alumno.EEstadoCuenta.Becado);

            universidad += alumnoUno;
        }
    }
}
