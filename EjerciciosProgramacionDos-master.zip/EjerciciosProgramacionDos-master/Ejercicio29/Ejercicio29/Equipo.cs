﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio29
{
    public class Equipo
    {
        private short cantidadDeJugadores;
        private List<Jugador> jugadores;
        private string nombre;

        private Equipo()
        {
            this.jugadores = new List<Jugador>();
        }

        public Equipo(short cantidad, string nombre) :this()
        {
            this.cantidadDeJugadores = cantidad;
            this.nombre = nombre;
        }

        public static bool operator +(Equipo equipo, Jugador jugador)
        {
            bool retorno = default;
            foreach  (Jugador jugadorAux in equipo.jugadores)
            {
                if((jugadorAux != jugador) && (equipo.jugadores.Count < equipo.cantidadDeJugadores))
                {
                    equipo.jugadores.Add(jugador);
                    retorno = true;
                }
                else
                {
                    retorno = false;
                }
            }
            return retorno;
        }
    }
}
