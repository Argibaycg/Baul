﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Local : Llamada
    {
        protected float costo;

        public Local(Llamada llamada, float costo) : base(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen)
        {

        }

        public Local(string origen, float duracion, string destino, float costo) : base(duracion, destino, origen)
        {
            this.costo = costo;
        }
        public override float CostoLlamada { get { return this.CalcularCosto(); } }

        protected override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.Mostrar());
            sb.AppendLine($"El costo de la llamada fue: {this.CostoLlamada}");

            return sb.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        public override bool Equals(Object objeto)
        {
            if(objeto is Local)
            {
                return true;
            }
            return false;
        }
        // return (obj.GetType() == typeof(Local));

        private float CalcularCosto()
        {
            return this.costo * this.Duracion;
        }


    }
}
