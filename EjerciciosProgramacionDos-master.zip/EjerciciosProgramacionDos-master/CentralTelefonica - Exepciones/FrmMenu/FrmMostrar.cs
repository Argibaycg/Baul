﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;

namespace FrmMenu
{
    public partial class FrmMostrar : Form
    {
        private Centralita centralita;
        public TipoLlamada tipoLlamada;

        public FrmMostrar(Centralita centralita)
        {
            InitializeComponent();
            this.centralita = centralita;
        }

        public TipoLlamada TipoLlamada { set{ this.tipoLlamada = value; } } 

        private void FrmMostrar_Load(object sender, EventArgs e)
        {
            switch (tipoLlamada)
            {
                case TipoLlamada.Local:
                    if (tipoLlamada is TipoLlamada.Local)
                    {
                        rtbFacturacion.Text = centralita.GananciasPorLocal.ToString();
                    }
                    break;
                case TipoLlamada.Provincial:
                    if (tipoLlamada is TipoLlamada.Provincial)
                    {
                        rtbFacturacion.Text = centralita.GananciasPorProvincial.ToString();
                    }
                    break;
                case TipoLlamada.Todas:
                    if (tipoLlamada is TipoLlamada.Todas)
                    {
                        rtbFacturacion.Text = centralita.GananciasPorTotal.ToString();
                    }
                    break;
            }
        }
    }
}
