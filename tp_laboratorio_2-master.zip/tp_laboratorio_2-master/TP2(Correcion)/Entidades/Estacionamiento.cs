﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    /// <summary>
    /// No podrá tener clases heredadas.
    /// </summary>
    public sealed class Estacionamiento
    {
        private List<Vehiculo> vehiculos;
        private int espacioDisponible;

        public enum ETipo
        {
            Moto, Automovil, Camioneta, Todos
        }

        #region "Constructores"

        /// <summary>
        /// Constructor privado que inicializa la lista de vehiculos 
        /// </summary>
        private Estacionamiento()
        {
            this.vehiculos = new List<Vehiculo>();
        }

        /// <summary>
        /// Constructor public que llama al privado e inicializa el espacio disponible
        /// </summary>
        /// <param name="espacioDisponible"></param>
        public Estacionamiento(int espacioDisponible) : this()
        {
            this.espacioDisponible = espacioDisponible;
        }
        #endregion

        #region "Sobrecargas"
        /// <summary>
        /// Muestro el estacionamiento y TODOS los vehículos
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Mostrar(this, ETipo.Todos);
        }
        #endregion

        #region "Métodos"

        /// <summary>
        /// Expone los datos del elemento y su lista (incluidas sus herencias)
        /// SOLO del tipo requerido
        /// </summary>
        /// <param name="estacionamiento">Elemento a exponer</param>
        /// <param name="ETipo">Tipos de ítems de la lista a mostrar</param>
        /// <returns></returns>
        public static string Mostrar(Estacionamiento estacionamiento, ETipo tipo)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Tenemos {0} lugares ocupados de un total de {1} disponibles", estacionamiento.vehiculos.Count, estacionamiento.espacioDisponible);
            sb.AppendLine("");
            foreach (Vehiculo vehiculo in estacionamiento.vehiculos)
            {
                switch (tipo)
                {
                    case ETipo.Camioneta:
                        if (vehiculo is Camioneta)
                            sb.AppendLine(vehiculo.Mostrar());
                        break;
                    case ETipo.Moto:
                        if (vehiculo is Moto)
                            sb.AppendLine(vehiculo.Mostrar());
                        break;
                    case ETipo.Automovil:
                        if (vehiculo is Automovil)
                            sb.AppendLine(vehiculo.Mostrar());
                        break;
                    default:
                        sb.AppendLine(vehiculo.Mostrar());
                        break;
                }
            }

            return sb.ToString();
        }
        #endregion

        #region "Operadores"
        /// <summary>
        /// Agregará un elemento a la lista
        /// </summary>
        /// <param name="estacionamiento">Objeto donde se agregará el elemento</param>
        /// <param name="vehiculo">Objeto a agregar</param>
        /// <returns></returns>
        public static Estacionamiento operator +(Estacionamiento estacionamiento, Vehiculo vehiculo)
        {
            if (estacionamiento.vehiculos.Count < estacionamiento.espacioDisponible)
            {
                foreach (Vehiculo vehiculoAux in estacionamiento.vehiculos)
                {
                    if (vehiculoAux == vehiculo)
                        return estacionamiento;
                }
                estacionamiento.vehiculos.Add(vehiculo);
            }
            return estacionamiento;
        }
        /// <summary>
        /// Quitará un elemento de la lista
        /// </summary>
        /// <param name="estacionamiento">Objeto donde se quitará el elemento</param>
        /// <param name="vehiculo">Objeto a quitar</param>
        /// <returns></returns>
        public static Estacionamiento operator -(Estacionamiento estacionamiento, Vehiculo vehiculo)
        {
            if (estacionamiento.vehiculos.Count > 0)
            {
                foreach (Vehiculo vehiculoAux in estacionamiento.vehiculos)
                {
                    if (vehiculoAux == vehiculo)
                    {
                        estacionamiento.vehiculos.Remove(vehiculoAux);
                        break;
                    }
                }
            }

            return estacionamiento;
        }
        #endregion
    }
}
