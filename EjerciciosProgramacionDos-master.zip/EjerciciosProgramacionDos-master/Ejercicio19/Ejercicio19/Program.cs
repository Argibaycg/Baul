﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio19
{
    class Program
    {
        static void Main(string[] args)
        {
            Sumador primerSumador = new Sumador();

            Sumador segundoSumador = new Sumador(10);

            Console.WriteLine(primerSumador.Sumar(10, 10));

            Console.WriteLine(segundoSumador.Sumar("10", "10"));

            int pepe = (int)primerSumador;

            Console.ReadKey();
        }
    }
}
