﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCatorce
{
    class Calcular
    {
        public static double CalcularCuadrado(double side)
        {
            return Math.Pow(side,2);
        }

        public static double CalcularTriangulo(double baseTriangle, double height)
        {
            return (baseTriangle * height) / 2;
        }

        public static double CalcularCirculo(double radius)
        {
            return radius / (Math.PI * Math.Pow(radius, 2));
        }
    }
}
