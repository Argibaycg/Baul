#include <stdio.h>
#include <stdlib.h>

int main(void) {

	menu();

	return 0;
}
