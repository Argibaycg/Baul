﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio30
{
    class AutoF1
    {
        private short cantidadCombustible;
        private bool enCompetencia;
        private string escuderia;
        private short numero;
        private short vueltasRestantes;


        public AutoF1()
        {
            this.enCompetencia = false;
            this.cantidadCombustible = 0;
            this.vueltasRestantes = 0;
        }
        public AutoF1(short numero, string escuderia) :this()
        {
            this.numero = numero;
            this.escuderia = escuderia;
        }

        public short CantidadCombustible { get {return this.cantidadCombustible; } set {this.cantidadCombustible = value; } }
        public bool EnCompetencia { get {return this.enCompetencia; } set {this.enCompetencia= value; } }
        public short VueltasRestantes { get {return this.vueltasRestantes; } set {this.vueltasRestantes= value; } }

        public static bool operator ==(AutoF1 autoUno, AutoF1 autoDos)
        {
            if(autoUno.numero == autoDos.numero && autoUno.escuderia == autoDos.escuderia)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(AutoF1 autoUno, AutoF1 autoDos)
        {
            if (!(autoUno == autoDos))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"La cantidad de combustible es: {this.CantidadCombustible}");
            if(this.enCompetencia == true)
            {
            sb.AppendLine("El auto esta en competencia");
            }
            else
            {
                sb.AppendLine("El auto no esta en competencia");
            }
            sb.AppendLine($"La escuderia es: {this.escuderia}");
            sb.AppendLine($"El numero de auto es: {this.numero}");
            sb.AppendLine($"La cantidad de vueltas restantes es: {this.vueltasRestantes}");

            return sb.ToString();
        }
    }
}
