﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio13
{
    public class Conversor
    {
        public static string DecimalBinario(double input)
        {
            string binario = "";
            do
            {
                if ((input % 2) == 0)
                    binario = "0" + binario;
                else
                    binario = "1" + binario;
                input = (int)(input / 2);
            } while (input > 0);
            return binario;
        }

        public static double BinarioDecimal(string input)
        {
            double numero = 0;
            int binario;
            for (int i = input.Length - 1; i >= 0; i--)
            {
                if (int.TryParse(input[input.Length - i - 1].ToString(), out binario))
                {
                    numero += binario * Math.Pow(2, i);
                }
                else
                {
                    return 0;
                }
            }
            return numero;
        }
    }
}
