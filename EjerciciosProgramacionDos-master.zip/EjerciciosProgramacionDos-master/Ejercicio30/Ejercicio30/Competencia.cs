﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio30
{
    class Competencia
    {
        private short cantidadCompetidores;
        private short cantidadVueltas;
        private List<AutoF1> competidores;

        private Competencia()
        {
            competidores = new List<AutoF1>();
        }

        public Competencia(short cantidadVueltas, short cantidadCompetidores) :this()
        {
            this.cantidadVueltas = cantidadVueltas;
            this.cantidadCompetidores = cantidadCompetidores;
        }


        public static bool operator +(Competencia competencia, AutoF1 auto)
        {
            Random rnd = new Random();
            if(competencia.cantidadCompetidores < competencia.competidores.Count && competencia.competidores.Contains(auto))
            {
                competencia.competidores.Add(auto);
                auto.EnCompetencia = true;
                auto.VueltasRestantes = competencia.cantidadVueltas;
                auto.CantidadCombustible = (short)rnd.Next(15, 100);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
