﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioSeis
{
    class Program
    {
        static void Main(string[] args)
        {
            int startYear;
            int endYear;

            Console.Write("Ingrese un año de Inicio: ");
            string aux = Console.ReadLine();
            int.TryParse(aux, out startYear);

            Console.Write("Ingrese un año de Fin: ");
            string auxTwo = Console.ReadLine();
            int.TryParse(auxTwo, out endYear);


            for (int i = startYear; i <= endYear; i++)
            {
                if (ValidBisiesto.EsBisiesto(i))
                {
                    Console.WriteLine("El año {0} es Bisiesto", i);
                }
            }
            Console.ReadKey();
        }

    }
}
