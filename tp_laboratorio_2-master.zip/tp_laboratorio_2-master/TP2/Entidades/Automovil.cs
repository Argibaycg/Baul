﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Drawing;

namespace Entidades
{
    public class Automovil : Vehiculo
    {
        public enum ETipo { Monovolumen, Sedan }
        
        ETipo tipo;

        /// <summary>
        /// Constructor que define por defecto el tipo en monovolumen y llama al constructor base
        /// </summary>
        /// <param name="marca">marca del automovil</param>
        /// <param name="chasis">chasis del automovil</param>
        /// <param name="color">color del automovil</param>
        public Automovil(EMarca marca, string chasis, ConsoleColor color) : base(chasis, marca, color)
        {
            this.tipo = ETipo.Monovolumen;
        }

        /// <summary>
        /// Constructor que recibe ademas de lo que pide la base, el tipo y lo asigna.
        /// </summary>
        /// <param name="marca">marca del automovil</param>
        /// <param name="chasis">chasis del automovil</param>
        /// <param name="color">color del automovil</param>
        public Automovil(EMarca marca, string chasis, ConsoleColor color, ETipo tipo) : this(marca, chasis, color)
        {
            this.tipo = tipo;
        }

        /// <summary>
        /// Los automoviles son medianos
        /// </summary>
        protected override ETamanio Tamanio
        {
            get
            {
                return ETamanio.Mediano;
            }
        }

        /// <summary>
        /// Sobreescribe el metodo mostrar ademas de llamar al metodo base para mostrar los datos del automovil
        /// </summary>
        /// <returns>retorna un string</returns>
        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("AUTOMOVIL");
            sb.AppendLine(base.Mostrar());
            sb.AppendFormat("TAMAÑO : {0}\t", this.Tamanio);
            sb.AppendLine("TIPO : " + this.tipo);
            sb.AppendLine("");
            sb.AppendLine("---------------------");

            return sb.ToString();
        }
    }
}
