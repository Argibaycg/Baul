﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
Ingresar 5 números por consola, guardándolos en una variable escalar. Luego calcular y mostrar: el valor máximo, el valor mínimo y el promedio 
*/
namespace EjercicioUno
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            int max = 0;
            int min = 0;
            int total = 0;
            int integer;

            while (count < 5)
            {
                Console.Write("Ingrese un numero: ");
                string aux = Console.ReadLine();
                int.TryParse(aux, out integer);

                total += integer;

                if (count == 0)
                {
                    max = integer;
                    min = integer;
                }
                else if (integer > max)
                {
                    max = integer;
                }
                else if (integer < min)
                {
                    min = integer;
                }
                count++;
            }

            Console.WriteLine("El mayor es: {0}", max);
            Console.WriteLine("El menor es: {0}", min);
            Console.WriteLine("El promedio es: {0}", total / 5);
            Console.ReadKey();
        }    
    }
}
