﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Centralita
    {
        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;

        public float GananciasPorLocal { get { return CalcularGanancia(TipoLlamada.Local); } }
        public float GananciasPorProvincial { get { return CalcularGanancia(TipoLlamada.Provincial); } }
        public float GananciasPorTotal { get { return CalcularGanancia(TipoLlamada.Todas); } }
        public List<Llamada> Llamadas { get { return this.listaDeLlamadas; } }

        public Centralita()
        {
            listaDeLlamadas = new List<Llamada>();
        }

        public Centralita(string nombreEmpresa) : this()
        {
            this.razonSocial = nombreEmpresa;
        }


        private float CalcularGanancia(TipoLlamada tipo)
        {
            float total = default;
            foreach (Llamada llamada in listaDeLlamadas)
            {
                switch (tipo)
                {
                    case TipoLlamada.Local:
                        if (llamada is Local)
                        {
                            total += llamada.CostoLlamada;
                        }
                        break;
                    case TipoLlamada.Provincial:
                        if (llamada is Provincial)
                        {
                            total += llamada.CostoLlamada;
                        }
                        break;
                    default:
                        total += llamada.CostoLlamada;
                        break;


                }
            }

            return total;
        }

        private string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"La razon social es: {razonSocial}\n");
            sb.AppendLine($"La ganancia total es: {GananciasPorTotal}");
            sb.AppendLine($"La ganancia Local es: {GananciasPorLocal}");
            sb.AppendLine($"La ganancia Provincial es: {GananciasPorProvincial}\n");
            foreach (Llamada llamada in listaDeLlamadas)
            {
                sb.AppendLine($"Las llamadas realizadas fueron: \n{llamada.ToString()}");
            }

            return sb.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        private void AgregarLlamada(Llamada nuevaLlamada)
        {
            listaDeLlamadas.Add(nuevaLlamada);
        }

        public static bool operator ==(Centralita centralita, Llamada llamada)
        {
            foreach (Llamada llamadaAux in centralita.listaDeLlamadas)
            {
                if (llamadaAux == llamada)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Centralita centralita, Llamada llamada)
        {
            return !(centralita == llamada);
        }

        public static Centralita operator +(Centralita centralita, Llamada llamada)
        {
            try
            {
                if (centralita != llamada)
                {
                    centralita.AgregarLlamada(llamada);
                }
                else
                {
                    throw new CentralitaException("No se puedo agregar llamada", "En la clase Centralita", "Sobrecarga +");
                }

            }
            catch (CentralitaException noSePuedeAgregarLLamadaException)
            {
                //Console.WriteLine(noSePuedeAgregarLLamadaException.ToString());
                throw new CentralitaException("No se puedo agregar llamada", "En la clase Centralita", "Sobrecarga +",noSePuedeAgregarLLamadaException);
            }
            return centralita;
        }



        public void OrdenarLlamadas()
        {
            listaDeLlamadas.Sort(Llamada.OrdenarPorDuracion);
        }
    }
}

