﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioNueve
{
    class Program
    {
        static void Main(string[] args)
        {
            int input;
            string output = "*";
            string outputTwo = "**";
            
            Console.Write("Cuantas lineas desea imprimir? ");
            string aux = Console.ReadLine();
            int.TryParse(aux, out input);

            for (int i = 0; i < input; i++)
            {
                Console.WriteLine(output);
                output += outputTwo;
            }

            Console.ReadKey();
        }
    }
}
