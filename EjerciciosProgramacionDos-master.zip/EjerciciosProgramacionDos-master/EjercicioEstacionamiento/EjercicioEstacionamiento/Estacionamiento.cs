﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEstacionamiento
{
    class Estacionamiento
    {
        private string nombreDeEstacionamineto;
        private Auto[] arrayAutos;
        private double precioPorAuto;
        private static Random numeroAleatorio;

        public Estacionamiento (string estacionamiento, int capacidadEstacionamiento) : this (capacidadEstacionamiento)
        {
            this.nombreDeEstacionamineto = estacionamiento;
        }

        public Estacionamiento(int capacidadEstacionamiento)
        {
            arrayAutos = new Auto[capacidadEstacionamiento];
            this.precioPorAuto = Estacionamiento.GenerarPrecio();
        }

        static Estacionamiento() //No se necesita crear un Objeto para poder usarlo
        {
            //Se ejecuta una sola vez
            numeroAleatorio = new Random();
        }

        public static int GenerarPrecio()
        {
            return numeroAleatorio.Next(100, 300);
        }

        public static bool operator ==(Estacionamiento estacionamiento, Auto auto)
        {
            foreach (Auto auxAuto in estacionamiento.arrayAutos)
            {

            }
        }
    }
}
