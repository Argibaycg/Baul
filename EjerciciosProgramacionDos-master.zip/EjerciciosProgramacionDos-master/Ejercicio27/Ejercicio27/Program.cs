﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio27
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Pilas
            Stack pilaNumeros = new Stack();
            int[] arrayNumeros = new int[20];

            int[] numerosPositivos = new int[20];
            int[] numerosNegativos = new int[20];

            Random numeroRandom = new Random();
            for (int i = 0; i <= 20; i++)
            {
                pilaNumeros.Push(numeroRandom.Next(-100, 100));
            }



            pilaNumeros.CopyTo(arrayNumeros, 0);

            
            
            #endregion

            Console.ReadKey();
        }
    }
}
