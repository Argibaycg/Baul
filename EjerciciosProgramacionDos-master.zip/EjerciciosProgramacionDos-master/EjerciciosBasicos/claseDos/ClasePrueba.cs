﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace claseDos
{
    public class ClasePrueba //especificar rapido 
    {
        public int atributo1;
        public static string atributo2;

        public int GetAtributo1()
        {
            return this.atributo1;
        }

        public static void SetAtributo2(string aux)
        {
            ClasePrueba.atributo2 = aux;
        }
    }
}
