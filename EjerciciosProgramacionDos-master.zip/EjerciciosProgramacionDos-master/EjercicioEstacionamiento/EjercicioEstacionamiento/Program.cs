﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEstacionamiento
{
    class Program
    {
        static void Main(string[] args)
        {

            Auto unAuto = new Auto("ASD123", 3200000);

            Console.WriteLine(unAuto.GetInfo());

            Console.ReadKey();


        }
    }
}
