﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }
    public abstract class Llamada
    {
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;


        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }

        public abstract float CostoLlamada { get; }
        public float Duracion { get { return this.duracion; } }
        public string NroDestino { get { return this.nroDestino; } }
        public string NroOrigen { get { return this.nroOrigen; } }

        public static int OrdenarPorDuracion(Llamada llamadaUno, Llamada llamadaDos)
        {
            int orden = default;
            if (llamadaUno.Duracion > llamadaDos.Duracion)
            {
                orden = 1;
            }
            else if (llamadaUno.Duracion < llamadaDos.Duracion)
            {
                orden = -1;
            }
            else
            {
                orden = 0;
            }
            return orden;
        }

        public static bool operator ==(Llamada llamadaUno, Llamada llamadaDos)
        {
            
            return llamadaUno.Equals(llamadaDos) && 
                llamadaUno.nroDestino == llamadaDos.nroDestino &&
                llamadaUno.nroOrigen == llamadaDos.nroOrigen;

        }

        public static bool operator !=(Llamada llamadaUno, Llamada llamadaDos)
        {

            return !(llamadaUno == llamadaDos);

        }

        protected virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"La duracion de la llamada fue: {Duracion}");
            sb.AppendLine($"El numero de origen fue: {NroOrigen}");
            sb.AppendLine($"El numero de destrino fue: {NroDestino}");

            return sb.ToString();
        }
    }
}
