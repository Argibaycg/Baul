#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Empleado.h"
#include "LinkedList.h"

/** \brief asigna espacio de memoria para un nuevo empleado
 * \return puntero del espacio de memoria
 */
Empleado* employee_new(){

	Empleado* empleado = (Empleado*)malloc( sizeof(Empleado));

	if(empleado != NULL)
	{
		empleado->id = 0;
		strcpy(empleado->nombre, "");
		empleado->horasTrabajadas = 0;
		empleado->sueldo = 0;
	}

return empleado;
}

/** \brief asigna espacio de memoria para em empleado y asigna por parametro los campos de la estructura
 * \param char* idStr
 * \param char* nombreStr
 * \param char* horasTrabajadasStr
 * \param char* sueldo
 * \return puntero del espacio de memoria
 */
Empleado* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadasStr)
{

	Empleado* empleado = employee_new();

	if(empleado != NULL)
	{
		employee_setId(empleado,atoi(idStr));
		employee_setNombre(empleado,nombreStr);
		employee_setHorasTrabajadas(empleado,atoi(horasTrabajadasStr));
	}
return empleado;
}

/** \brief asigna el id al campo del empleado
 * \param Employee* this
 * \param int id
 * \return int
 */
int employee_setId(Empleado* this,int id)
{
	int retorno = -1;

	if(this != NULL)
	{
		this->id = id;
		retorno = 0;
	}

	return retorno;
}

/** \brief obtiene el id del campo del empleado
 * \param Employee* this
 * \param int id
 * \return int
 */
int employee_getId(Empleado* this,int* id)
{
	int retorno = -1;

	if(this != NULL && id != NULL)
	{
		*id = this->id;
		retorno = 0;
	}

	return retorno;
}

/** \brief asigna el nombre al campo del empleado
 * \param Employee* this
 * \param char* nombre
 * \return int
 */
int employee_setNombre(Empleado* this,char* nombre)
{
	int retorno = -1;

	if(this != NULL)
	{
		strcpy(this->nombre, nombre);
		retorno = 0;
	}

	return retorno;
}

/** \brief obtiene el nombre trabajadas del campo del empleado
 * \param Employee* this
 * \param char* nombre
 * \return int
 */
int employee_getNombre(Empleado* this,char* nombre)
{
	int retorno = -1;

	if(this != NULL && nombre != NULL)
	{
		strcpy(nombre, this->nombre);
		retorno = 0;
	}

	return retorno;

}

/** \brief asigna las horas trabajadas al campo del empleado
 * \param Employee* this
 * \param int horasTrabajadas
 * \return int
 */
int employee_setHorasTrabajadas(Empleado* this,int horasTrabajadas)
{
	int retorno = -1;

	if(this != NULL)
	{
		this->horasTrabajadas = horasTrabajadas;
		retorno = 0;
	}

	return retorno;
}

/** \brief obtiene las horas trabajadas del campo del empleado
 * \param Employee* this
 * \param int* horasTrabajadas
 * \return int
 */
int employee_getHorasTrabajadas(Empleado* this,int* horasTrabajadas)
{
	int retorno = -1;

	if(this != NULL && horasTrabajadas != NULL)
	{
		*horasTrabajadas = this->horasTrabajadas;
		retorno = 0;
	}

	return retorno;
}

/** \brief asigna el sueldo al campo del empleado
 * \param Employee* this
 * \param int sueldo
 * \return int
 */
int employee_setSueldo(Empleado* this,int sueldo)
{
	int retorno = -1;

	if(this != NULL)
	{
		this->sueldo = sueldo;
		retorno = 0;
	}

	return retorno;
}

/** \brief obtiene el sueldo del campo del empleado
 * \param Employee* this
 * \param int sueldo
 * \return int
 */
int employee_getSueldo(Empleado* this,int* sueldo)
{
	int retorno = -1;

	if(this != NULL && sueldo != NULL)
	{
		*sueldo = this->sueldo;
		retorno = 0;
	}

	return retorno;
}
void em_calcularSueldo(void* p)
{
	int auxHorasTrabajadas;
	int auxiliarSueldo;
	Empleado* auxiliar;

	auxiliar = (Empleado*)p;

	if(auxiliar != NULL)
	{
		auxHorasTrabajadas = auxiliar->horasTrabajadas;
	}

	if(auxHorasTrabajadas <= 120)
	{
		auxiliarSueldo = auxHorasTrabajadas*180;
	}
	if(auxHorasTrabajadas > 120 && auxHorasTrabajadas <= 160)
	{
		auxiliarSueldo = 120 * 180;
		auxHorasTrabajadas -= 120;
		auxiliarSueldo += auxHorasTrabajadas * 240;
	}
	if(auxHorasTrabajadas > 160)
	{
		auxiliarSueldo = 120 * 180;
		auxiliarSueldo = 40 * 240;
		auxHorasTrabajadas -= 160;
		auxiliarSueldo += auxHorasTrabajadas * 350;
	}
	auxiliar->sueldo = auxiliarSueldo;

//	   Los valores de horas varian entre 80 y 240.
//	    - Las primeras 120 horas la hora vale $180
//	    - De 120 a 160 horas, la hora vale $240
//	    - De 160 a 240 horas, la hora vale $350
}
