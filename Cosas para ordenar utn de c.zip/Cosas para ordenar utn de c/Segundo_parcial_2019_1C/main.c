#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Empleado.h"
#include "LinkedList.h"
#include "Parser.h"


int main()
{

    
	LinkedList* listaRevelados = ll_newLinkedList();



    if(parser_parseEmpleados("archivo.csv",listaEmpleados)==1)
    {
        
        printf("leyo todo piola vago");

    }else
    {
    	printf("Error leyendo revelados\n");

    }


    return 0;
}


