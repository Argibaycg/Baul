﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Billetes;

namespace Ejercicio23
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCandado_Click(object sender, EventArgs e)
        {
            if (txtCotizacionEuro.Enabled == true)
            {

                txtCotizacionEuro.Enabled = false;
                txtCotizacionDolar.Enabled = false;
                txtCotizacionPeso.Enabled = false;
            }
            else
            {

                txtCotizacionEuro.Enabled = true;
                txtCotizacionDolar.Enabled = true;
                txtCotizacionPeso.Enabled = true;
            }
        }

        private void txtCotizacionEuro_Leave(object sender, EventArgs e)
        {
            double aux = 0;
            if (double.TryParse(txtCotizacionEuro.Text, out aux))
                Euro.SetCotizacion(aux);
            else
                txtCotizacionEuro.Focus();
        }

        private void txtCotizacionDolar_Leave(object sender, EventArgs e)
        {
            double aux = 0;
            if (double.TryParse(txtCotizacionDolar.Text, out aux))
                Dolar.SetCotizacion(aux);
            else
                txtCotizacionDolar.Focus();
        }

        private void txtCotizacionPeso_Leave(object sender, EventArgs e)
        {
            double aux = 0;
            if (double.TryParse(txtCotizacionPeso.Text, out aux))
                Peso.SetCotizacion(aux);
            else
                txtCotizacionPeso.Focus();
        }

        private void btnConvertEuro_Click(object sender, EventArgs e)
        {
            double euro;
            
            txtEuroaEuro.Text = txtEuro.Text;

            double.TryParse(txtEuro.Text, out euro);

            Euro nuevoEuro = new Euro(euro);

            Dolar euroConvertidoDolar = (Dolar)nuevoEuro;
            
            txtEuroaDolar.Text = euroConvertidoDolar.ToString();
        }
    }
}
