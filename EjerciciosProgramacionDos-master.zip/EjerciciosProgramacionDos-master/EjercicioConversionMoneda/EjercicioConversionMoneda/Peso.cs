﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Peso
    {
        private double cantidad;
        private static double cotizRespectoDolar;
        static Peso()
        {
            Peso.cotizRespectoDolar = 1;
        }

        public Peso(double cantidad)
        {
            this.cantidad = cantidad;
        }
        public Peso(double cantidad, double cotizacion) : this(cantidad)
        {
            Peso.cotizRespectoDolar = cotizacion;
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static double GetCotizacion()
        {
            return Peso.cotizRespectoDolar;
        }

        #region Conversiones
        public static implicit operator Peso(double dolar)
        {
            Peso aux = new Peso(dolar);
            return aux;
        }

        public static explicit operator Dolar(Peso peso)
        {
            return new Dolar(peso.cantidad / Peso.GetCotizacion());
        }

        public static explicit operator Euro(Peso peso)
        {
            return (Euro)((Dolar)peso);
        }
        #endregion

        #region Operaciones
        public static Peso operator +(Peso peso, Euro euro)
        {
            Peso aux = new Peso(peso.cantidad + ((Peso)euro).cantidad);
            return aux;
        }

        public static Peso operator +(Peso peso, Dolar dolar)
        {
            Peso aux = new Peso(peso.cantidad + ((Peso)dolar).cantidad);
            return aux;
        }

        public static Peso operator -(Peso peso, Euro euro)
        {
            Peso aux = new Peso(peso.cantidad - ((Peso)euro).cantidad);
            return aux;
        }

        public static Peso operator -(Peso peso, Dolar dolar)
        {
            Peso aux = new Peso(peso.cantidad - ((Peso)dolar).cantidad);
            return aux;
        }
        #endregion
    }
}
