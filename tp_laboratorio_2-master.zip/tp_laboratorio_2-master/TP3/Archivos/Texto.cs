﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Excepciones;
using System.Net.Http.Headers;

namespace Archivos
{
    
    public class Texto : IArchivo<string>
    {
        /// <summary>
        /// Metodo que guarda en archivo de texto
        /// </summary>
        /// <param name="archivo">Archivo donde se guardara la Jornada</param>
        /// <param name="datos">Datos de la jornada a guardar</param>
        /// <returns></returns>
        public bool Guardar(string archivo, string datos)
        {
            bool retorno = false;
            StreamWriter streamWriter = null;
            try
            {
                streamWriter = new StreamWriter(archivo);
                streamWriter.Write(datos);
                retorno = true;
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }
            finally
            {
                streamWriter.Close();
            }

            return retorno;
        }

        /// <summary>
        /// Metodo para ller el archivo de Jornadas
        /// </summary>
        /// <param name="archivo">Archivo de jornadar</param>
        /// <param name="datos">Datos de la Jornada</param>
        /// <returns></returns>
        public bool Leer(string archivo, out string datos)
        {
            bool retorno = false;
            datos = string.Empty;
            if (File.Exists(archivo))
            {
                StreamReader streamReader = null;
                try
                {
                    streamReader = new StreamReader(archivo);
                    datos = streamReader.ReadToEnd();
                    retorno = true;
                }
                catch (Exception e)
                {
                    throw new ArchivosException(e);
                }
                finally
                {
                    streamReader.Close();
                }
            }
            return retorno;
        }
    }
}
