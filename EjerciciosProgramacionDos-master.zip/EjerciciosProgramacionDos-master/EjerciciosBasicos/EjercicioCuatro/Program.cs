﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCuatro
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            int number = 2;

            while(count != 4)
            {

                int totalDivisores = Program.sumaDivisores(number);
                if(totalDivisores == number)
                {
                    Console.WriteLine("Numero Perfecto: {0}", number);
                    count++;
                }
                number++;
            }

            Console.ReadKey();
        }

        public static int sumaDivisores(int number)
        {
            int counter = 1;

            for (int i = 2; i < number; i++)
            {
                if (number % i == 0)
                {
                    counter += i;
                }
            }

            return counter;
        }
    }
}
