﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDoce
{
    class Program
    {
        public static void Main(string[] args)
        {
            int input;
            int total = 0;
            char keepCounting;

            do
            {
                Console.WriteLine("Ingrese un numero: ");
                string aux = Console.ReadLine();
                int.TryParse(aux, out input);

                total += input;

                Console.WriteLine("¿Continuar? (S/N): ");
                keepCounting = Console.ReadKey().KeyChar;
              
            } while (ValidarRespuesta.ValidarS_N(keepCounting));

            Console.WriteLine("El total de numeros ingresados es: {0}", total);

            Console.ReadKey();
        }
    }
}
