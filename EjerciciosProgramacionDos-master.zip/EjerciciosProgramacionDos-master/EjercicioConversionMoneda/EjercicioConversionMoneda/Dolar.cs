﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Dolar
    {
        private double cantidad;
        private static double cotizRespectoDolar;

        static Dolar()
        {
            Dolar.cotizRespectoDolar = 1;
        }

        public Dolar(double cantidad)
        {
            this.cantidad = cantidad;
        }
        public Dolar(double cantidad, double cotizacion) : this(cantidad)
        {
            Dolar.cotizRespectoDolar = cotizacion;
        }


        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static double GetCotizacion()
        {
            return Dolar.cotizRespectoDolar;
        }

        #region Conversiones

        public static implicit operator Dolar(double dolar)
        {
            Dolar aux = new Dolar(dolar);
            return aux;
        }

        public static explicit operator Peso(Dolar dolar)
        {
            return new Peso(dolar.cantidad * Peso.GetCotizacion());
        }

        public static explicit operator Euro(Dolar dolar)
        {
            return new Euro(dolar.cantidad * Euro.GetCotizacion());
        }
        #endregion

        #region Operaciones
        public static Dolar operator +(Dolar dolar, Peso peso)
        {
            Dolar aux = new Dolar(dolar.cantidad + ((Dolar)peso).cantidad);
            return aux;
        }

        public static Dolar operator +(Dolar dolar, Euro euro)
        {
            Dolar aux = new Dolar(dolar.cantidad + ((Dolar)euro).cantidad);
            return aux;
        }

        public static Dolar operator -(Dolar dolar, Peso peso)
        {
            Dolar aux = new Dolar(dolar.cantidad - ((Dolar)peso).cantidad);
            return aux;
        }

        public static Dolar operator -(Dolar dolar, Euro euro)
        {
            Dolar aux = new Dolar(dolar.cantidad - ((Dolar)euro).cantidad);
            return aux;
        }
        #endregion

        #region Comparaciones
        public static bool operator ==(Dolar dolarUno, Dolar dolarDos)
        {
            return dolarUno.cantidad == dolarDos.cantidad;
        }

        public static bool operator !=(Dolar dolarUno, Dolar dolarDos)
        {
            return !(dolarUno == dolarDos);
        }

        public static bool operator ==(Dolar dolar, Peso peso)
        {
            return dolar == (Dolar)peso;
        }

        public static bool operator !=(Dolar dolar, Peso peso)
        {
            return !(dolar == peso);
        }

        public static bool operator ==(Dolar dolar, Euro euro)
        {
            return dolar == (Dolar)euro;
        }

        public static bool operator !=(Dolar dolar, Euro euro)
        {
            return !(dolar == euro);
        }
        #endregion
    }

}
