﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioTres
{
    class Program
    {
        static void Main(string[] args)
        {
            int input;
            Console.Write("Ingrese un numero: ");
            string aux = Console.ReadLine();
            int.TryParse(aux, out input);

            for (int i = 1; i < (input + 1); i++)
            {
                int a = 0;
                for (int j = 1; j < (i + 1); j++)
                {
                    if (i % j == 0)
                    {
                        a++;
                    }
                }
                if (a == 2)
                {
                    Console.WriteLine("Primo Encontrado: {0}",i);
                }

            }

            Console.ReadLine();
        }
    }
}
