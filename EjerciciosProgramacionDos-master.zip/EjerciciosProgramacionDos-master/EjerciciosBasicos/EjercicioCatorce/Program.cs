﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCatorce
{
    class Program
    {
        public static void Main(string[] args)
        {
            double input;
            double inputTwo;
            double result;
            
            Console.WriteLine("Que area desea calcular?(cuadrado, triangulo, circulo).");
            string geometricShape = Console.ReadLine();
            
            if(geometricShape == "cuadrado")
            {
                Console.WriteLine("Ingrese la distancia del lado: ");
                string side = Console.ReadLine();
                double.TryParse(side, out input);
                
                result = Calcular.CalcularCuadrado(input);
                Console.WriteLine("El area del cuadrado es: {0}", result);
            }

            if (geometricShape == "triangulo")
            {
                Console.WriteLine("Ingrese la base del triangulo: ");
                string baseTriangle = Console.ReadLine();
                double.TryParse(baseTriangle, out input);

                Console.WriteLine("Ingrese la altura del triangulo: ");
                string height = Console.ReadLine();
                double.TryParse(height, out inputTwo);

                result = Calcular.CalcularTriangulo(input, inputTwo);
                Console.WriteLine("El area del triangulo es: {0}", result);
            }

            if (geometricShape == "circulo")
            {
                Console.WriteLine("Ingrese el radio del circulo: ");
                string radius = Console.ReadLine();
                double.TryParse(radius, out input);

                result = Calcular.CalcularCuadrado(input);
                Console.WriteLine("El area del cuadrado es: {0}", result);
            }

            Console.ReadKey();
        }
    }
}
