﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BibliotecaDeClases
{

    public class Torneo : Equipo , IEquatable<T>, IEnumerable<T>
    {
        IEnumerable<string> nombre;
        IEquatable<int> equipos;
        byte numero = null;
        static Random randomEquipos;
        static Random randomResultados;
        public Torneo(string nombre)
        {
            this.nombre = nombre;
            this.equipos = new List<T>();
        }

        static Torneo()
        {
            randomEquipos = new Random();
            randomResultados = new Random();
        }

        public string JugarPartido { 
            
            get 
            {
                T equipoUno;
                T equipoDos;
                do
                {
                equipoUno = equipos.ElementAt(randomEquipos.Next(equipos.Count()));
                equipoDos = equipos.ElementAt(randomEquipos.Next(equipos.Count()));
                } while (equipoUno.nombre == equipoDos.nombre);

                return CalcularPartido(equipoUno, equipoDos);
            } 
        }

        public static bool operator ==(Torneo<T> equipos, T unEquipo) {
            bool retorno = false;
            foreach (T equipo in equipos.equipos)
            {
                if (equipo == unEquipo)
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Torneo<T> equipos, T unEquipo)
        {
            return !(equipos == unEquipo);
        }

        public static Torneo<T> operator +(Torneo<T> equipos, T unEquipo)
        {
            if (equipos == unEquipo)
            {
                return equipos;
            }
            else {
                equipos.equipos.Add(unEquipo);
                return equipos;
            }        
        }

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            
            sb.AppendLine($"El nombre del torneo es {this.nombre}\n");
            
            foreach (T equipo in this.equipos)
            {
                sb.AppendLine(equipo.Ficha(equipo));
            }
            return sb.ToString();
        }

        private string CalcularPartido(T equipoUno, T equipoDos) 
        {
            
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{equipoUno.nombre} {randomResultados.Next(0, 10)} - {randomResultados.Next(0, 10)} {equipoDos.nombre}\n");

            return sb.ToString();
        }


    }
}
