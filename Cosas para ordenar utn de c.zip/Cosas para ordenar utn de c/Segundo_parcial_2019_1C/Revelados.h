#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED

struct S_Revelado
{
  int ID_Venta;
  char Fecha_Venta[128];
  char Tipo_Foto[128];
  int Cantidad;
  float Precio_Unitario;
  char CUIT_Cliente[128];
};
typedef struct S_Revelado Revelado;



#endif // EMPLEADO_H_INCLUDED


