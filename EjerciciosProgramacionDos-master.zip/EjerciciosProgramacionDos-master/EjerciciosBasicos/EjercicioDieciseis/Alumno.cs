﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDieciseis
{
    public class Alumno
    {
        public byte nota1;
        public byte nota2;
        public float notaFinal = -1;
        public string apellido;
        public int legajo;
        public string nombre;
        
        public void Estudiar(byte notaUno, byte notaDos)
        {
            this.nota1 = notaUno;
            this.nota2 = notaDos;
        }

        public void CalcularFinal()
        {
            if(this.nota1 >= 4 && this.nota2 >= 4)
            {
                Random rnd = new Random();
                this.notaFinal = rnd.Next();
            }
            
        }

        public string Mostrar()
        {
            if(this.notaFinal != -1)
            {
                return "El nombre es: " + this.nombre + "\n" +"El apellido es: " + this.apellido + "\n"
                        + "La primer nota es: " + this.nota1 + "\n" + "La segunda nota es: " + this.nota2 + "\n"
                        + "La nota final es: " + this.notaFinal;
            }
            else
            {
                return "Alumno desaprobado.";
            }
        }
    }
}
