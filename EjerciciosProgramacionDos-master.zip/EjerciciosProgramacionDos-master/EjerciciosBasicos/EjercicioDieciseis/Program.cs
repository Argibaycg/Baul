﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDieciseis
{
    class Program
    {
        static void Main(string[] args)
        {
            byte nota1;
            byte nota2;

            Alumno AlumnoUno = new Alumno();
            Alumno AlumnoDos = new Alumno();
            Alumno AlumnoTres = new Alumno();

            AlumnoUno.nombre = "Pepe";
            AlumnoUno.apellido = "Gonzales";
            AlumnoUno.legajo = 001;

            AlumnoDos.nombre = "Luis";
            AlumnoDos.apellido = "Pepe";
            AlumnoDos.legajo = 002;

            AlumnoTres.nombre = "Wos";
            AlumnoTres.apellido = "Lucindez";
            AlumnoTres.legajo = 003;

            Console.Write("Ingrese la primer nota: ");
            string aux = Console.ReadLine();
            byte.TryParse(aux, out nota1);

            Console.Write("Ingrese la segunda nota: ");
            string auxTwo = Console.ReadLine();
            byte.TryParse(auxTwo, out nota2);

            AlumnoUno.Estudiar(nota1,nota2);
            
            Console.Write("Ingrese la primer nota: ");
            aux = Console.ReadLine();
            byte.TryParse(aux, out nota1);

            Console.Write("Ingrese la segunda nota: ");
            auxTwo = Console.ReadLine();
            byte.TryParse(auxTwo, out nota2);

            AlumnoDos.Estudiar(nota1, nota2);

            Console.Write("Ingrese la primer nota: ");
            aux = Console.ReadLine();
            byte.TryParse(aux, out nota1);

            Console.Write("Ingrese la segunda nota: ");
            auxTwo = Console.ReadLine();
            byte.TryParse(auxTwo, out nota2);

            AlumnoTres.Estudiar(nota1, nota2);

            AlumnoUno.CalcularFinal();
            AlumnoDos.CalcularFinal();
            AlumnoTres.CalcularFinal();

            Console.WriteLine(AlumnoUno.Mostrar());
            Console.WriteLine(AlumnoDos.Mostrar());
            Console.WriteLine(AlumnoTres.Mostrar());


            Console.ReadKey();
        }
    }
}
