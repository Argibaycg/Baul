﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ejercicio56
{
    public partial class Form1 : Form
    {
        string fileContent = string.Empty;
        string filePath = string.Empty;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFile = new OpenFileDialog();

            openFile.InitialDirectory = "c:\\";
            openFile.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFile.FilterIndex = 2;
            openFile.RestoreDirectory = true;

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                filePath = openFile.FileName;

                StreamReader reader = new StreamReader(filePath);

                fileContent = reader.ReadToEnd();
                reader.Close(); 
            }
            rtbTextoPlano.Text = fileContent;
        }

        private void guardareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StreamWriter myStream;
            if (fileContent != string.Empty && filePath != string.Empty)
            {
                myStream = new StreamWriter(filePath, true);
                myStream.Write(rtbTextoPlano.Text);
                myStream.Close();
            }
            else
            {
                guardarComoToolStripMenuItem_Click(sender,e);
            }
        }

        private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StreamWriter writerStream;
            SaveFileDialog saveAsDialog = new SaveFileDialog();

            saveAsDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            saveAsDialog.FilterIndex = 2;
            saveAsDialog.RestoreDirectory = true;

            if (saveAsDialog.ShowDialog() == DialogResult.OK)
            {
                writerStream = new StreamWriter(saveAsDialog.FileName, true);
                writerStream.Write(rtbTextoPlano.Text);
                writerStream.Close();
            }
        }

        private void rtbTextoPlano_KeyPress(object sender, KeyPressEventArgs e)
        {
            int cantidadLetras = rtbTextoPlano.Text.ToString().Length;
            strLabel.Text = cantidadLetras.ToString() + " Caracteres";
        }
    }
}
