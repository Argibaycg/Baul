﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Euro
    {
        private double cantidad;
        private static double cotizRespectoDolar;
        static Euro()
        {
            Euro.cotizRespectoDolar = 1;
        }

        public Euro(double cantidad)
        {
            this.cantidad = cantidad;
        }
        public Euro(double cantidad, double cotizacion) : this(cantidad)
        {
            Euro.cotizRespectoDolar = cotizacion;
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static double GetCotizacion()
        {
            return Euro.cotizRespectoDolar;
        }

        #region Conversiones
        public static implicit operator Euro(double dolar)
        {
            Euro aux = new Euro(dolar);
            return aux;
        }

        public static explicit operator Dolar(Euro euro)
        {
            return new Dolar(euro.cantidad / Euro.GetCotizacion());
        }

        public static explicit operator Peso(Euro euro)
        {
            return (Peso)((Dolar)euro);//e.cantidad / Euro.GetCotizacion());
        }
        #endregion

        #region Operaciones
        public static Euro operator +(Euro euro, Peso peso)
        {
            Euro aux = new Euro(euro.cantidad + ((Euro)peso).cantidad);
            return aux;
        }

        public static Euro operator +(Euro euro, Dolar dolar)
        {
            Euro aux = new Euro(euro.cantidad + ((Euro)dolar).cantidad);
            return aux;
        }

        public static Euro operator -(Euro euro, Peso peso)
        {
            Euro aux = new Euro(euro.cantidad - ((Euro)peso).cantidad);
            return aux;
        }

        public static Euro operator -(Euro euro, Dolar dolar)
        {
            Euro aux = new Euro(euro.cantidad - ((Euro)dolar).cantidad);
            return aux;
        }
        #endregion

        #region Comparaciones
        public static bool operator ==(Euro euroUno, Euro euroDos)
        {
            return euroUno.cantidad == euroDos.cantidad;
        }

        public static bool operator !=(Euro euroUno, Euro euroDos)
        {
            return !(euroUno == euroDos);
        }

        public static bool operator ==(Euro euro, Peso peso)
        {
            return euro == (Euro)peso;
        }

        public static bool operator !=(Euro euro, Peso peso)
        {
            return !(euro == peso);
        }

        public static bool operator ==(Euro euro, Dolar dolar)
        {
            return euro == (Euro)dolar;
        }

        public static bool operator !=(Euro euro, Dolar dolar)
        {
            return !(euro == dolar);
        }
        #endregion
    }
}
