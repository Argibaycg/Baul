﻿namespace FrmMenu
{
    partial class FrmLlamador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNroDestino = new System.Windows.Forms.TextBox();
            this.txtNroOrigen = new System.Windows.Forms.TextBox();
            this.cbmFranjas = new System.Windows.Forms.ComboBox();
            this.gpbPanel = new System.Windows.Forms.GroupBox();
            this.btnNroNumeral = new System.Windows.Forms.Button();
            this.btnNroCero = new System.Windows.Forms.Button();
            this.btnAsterisco = new System.Windows.Forms.Button();
            this.btnNroNueve = new System.Windows.Forms.Button();
            this.btnNroOcho = new System.Windows.Forms.Button();
            this.btnNroSiete = new System.Windows.Forms.Button();
            this.btnNroSeis = new System.Windows.Forms.Button();
            this.btnNroCinco = new System.Windows.Forms.Button();
            this.btnNroCuatro = new System.Windows.Forms.Button();
            this.btnNroTres = new System.Windows.Forms.Button();
            this.btnNroDos = new System.Windows.Forms.Button();
            this.btnNroUno = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnLlamar = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.gpbPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNroDestino
            // 
            this.txtNroDestino.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNroDestino.Location = new System.Drawing.Point(17, 12);
            this.txtNroDestino.Name = "txtNroDestino";
            this.txtNroDestino.ReadOnly = true;
            this.txtNroDestino.Size = new System.Drawing.Size(368, 31);
            this.txtNroDestino.TabIndex = 0;
            this.txtNroDestino.Text = "Nro Destino";
            this.txtNroDestino.TextChanged += new System.EventHandler(this.txtNroDestino_TextChanged);
            this.txtNroDestino.Leave += new System.EventHandler(this.txtNroDestino_Leave);
            // 
            // txtNroOrigen
            // 
            this.txtNroOrigen.Location = new System.Drawing.Point(215, 191);
            this.txtNroOrigen.Name = "txtNroOrigen";
            this.txtNroOrigen.Size = new System.Drawing.Size(170, 20);
            this.txtNroOrigen.TabIndex = 1;
            this.txtNroOrigen.Text = "Nro Origen";
            // 
            // cbmFranjas
            // 
            this.cbmFranjas.AllowDrop = true;
            this.cbmFranjas.FormattingEnabled = true;
            this.cbmFranjas.Location = new System.Drawing.Point(17, 300);
            this.cbmFranjas.Name = "cbmFranjas";
            this.cbmFranjas.Size = new System.Drawing.Size(368, 21);
            this.cbmFranjas.TabIndex = 2;
            this.cbmFranjas.Text = "Franja";
            // 
            // gpbPanel
            // 
            this.gpbPanel.Controls.Add(this.btnNroNumeral);
            this.gpbPanel.Controls.Add(this.btnNroCero);
            this.gpbPanel.Controls.Add(this.btnAsterisco);
            this.gpbPanel.Controls.Add(this.btnNroNueve);
            this.gpbPanel.Controls.Add(this.btnNroOcho);
            this.gpbPanel.Controls.Add(this.btnNroSiete);
            this.gpbPanel.Controls.Add(this.btnNroSeis);
            this.gpbPanel.Controls.Add(this.btnNroCinco);
            this.gpbPanel.Controls.Add(this.btnNroCuatro);
            this.gpbPanel.Controls.Add(this.btnNroTres);
            this.gpbPanel.Controls.Add(this.btnNroDos);
            this.gpbPanel.Controls.Add(this.btnNroUno);
            this.gpbPanel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gpbPanel.Location = new System.Drawing.Point(21, 59);
            this.gpbPanel.Name = "gpbPanel";
            this.gpbPanel.Size = new System.Drawing.Size(172, 221);
            this.gpbPanel.TabIndex = 3;
            this.gpbPanel.TabStop = false;
            this.gpbPanel.Text = "Panel";
            // 
            // btnNroNumeral
            // 
            this.btnNroNumeral.Location = new System.Drawing.Point(115, 165);
            this.btnNroNumeral.Name = "btnNroNumeral";
            this.btnNroNumeral.Size = new System.Drawing.Size(44, 43);
            this.btnNroNumeral.TabIndex = 11;
            this.btnNroNumeral.Text = "#";
            this.btnNroNumeral.UseVisualStyleBackColor = true;
            this.btnNroNumeral.Click += new System.EventHandler(this.btnNroNumeral_Click);
            // 
            // btnNroCero
            // 
            this.btnNroCero.Location = new System.Drawing.Point(65, 165);
            this.btnNroCero.Name = "btnNroCero";
            this.btnNroCero.Size = new System.Drawing.Size(44, 43);
            this.btnNroCero.TabIndex = 10;
            this.btnNroCero.Text = "0";
            this.btnNroCero.UseVisualStyleBackColor = true;
            this.btnNroCero.Click += new System.EventHandler(this.btnNroCero_Click);
            // 
            // btnAsterisco
            // 
            this.btnAsterisco.Location = new System.Drawing.Point(15, 165);
            this.btnAsterisco.Name = "btnAsterisco";
            this.btnAsterisco.Size = new System.Drawing.Size(44, 43);
            this.btnAsterisco.TabIndex = 9;
            this.btnAsterisco.Text = "*";
            this.btnAsterisco.UseVisualStyleBackColor = true;
            this.btnAsterisco.Click += new System.EventHandler(this.btnAsterisco_Click);
            // 
            // btnNroNueve
            // 
            this.btnNroNueve.Location = new System.Drawing.Point(115, 116);
            this.btnNroNueve.Name = "btnNroNueve";
            this.btnNroNueve.Size = new System.Drawing.Size(44, 43);
            this.btnNroNueve.TabIndex = 8;
            this.btnNroNueve.Text = "9";
            this.btnNroNueve.UseVisualStyleBackColor = true;
            this.btnNroNueve.Click += new System.EventHandler(this.btnNroNueve_Click);
            // 
            // btnNroOcho
            // 
            this.btnNroOcho.Location = new System.Drawing.Point(65, 116);
            this.btnNroOcho.Name = "btnNroOcho";
            this.btnNroOcho.Size = new System.Drawing.Size(44, 43);
            this.btnNroOcho.TabIndex = 7;
            this.btnNroOcho.Text = "8";
            this.btnNroOcho.UseVisualStyleBackColor = true;
            this.btnNroOcho.Click += new System.EventHandler(this.btnNroOcho_Click);
            // 
            // btnNroSiete
            // 
            this.btnNroSiete.Location = new System.Drawing.Point(15, 116);
            this.btnNroSiete.Name = "btnNroSiete";
            this.btnNroSiete.Size = new System.Drawing.Size(44, 43);
            this.btnNroSiete.TabIndex = 6;
            this.btnNroSiete.Text = "7";
            this.btnNroSiete.UseVisualStyleBackColor = true;
            this.btnNroSiete.Click += new System.EventHandler(this.btnNroSiete_Click);
            // 
            // btnNroSeis
            // 
            this.btnNroSeis.Location = new System.Drawing.Point(115, 67);
            this.btnNroSeis.Name = "btnNroSeis";
            this.btnNroSeis.Size = new System.Drawing.Size(44, 43);
            this.btnNroSeis.TabIndex = 5;
            this.btnNroSeis.Text = "6";
            this.btnNroSeis.UseVisualStyleBackColor = true;
            this.btnNroSeis.Click += new System.EventHandler(this.btnNroSeis_Click);
            // 
            // btnNroCinco
            // 
            this.btnNroCinco.Location = new System.Drawing.Point(65, 67);
            this.btnNroCinco.Name = "btnNroCinco";
            this.btnNroCinco.Size = new System.Drawing.Size(44, 43);
            this.btnNroCinco.TabIndex = 4;
            this.btnNroCinco.Text = "5";
            this.btnNroCinco.UseVisualStyleBackColor = true;
            this.btnNroCinco.Click += new System.EventHandler(this.btnNroCinco_Click);
            // 
            // btnNroCuatro
            // 
            this.btnNroCuatro.Location = new System.Drawing.Point(15, 67);
            this.btnNroCuatro.Name = "btnNroCuatro";
            this.btnNroCuatro.Size = new System.Drawing.Size(44, 43);
            this.btnNroCuatro.TabIndex = 3;
            this.btnNroCuatro.Text = "4";
            this.btnNroCuatro.UseVisualStyleBackColor = true;
            this.btnNroCuatro.Click += new System.EventHandler(this.btnNroCuatro_Click);
            // 
            // btnNroTres
            // 
            this.btnNroTres.Location = new System.Drawing.Point(115, 18);
            this.btnNroTres.Name = "btnNroTres";
            this.btnNroTres.Size = new System.Drawing.Size(44, 43);
            this.btnNroTres.TabIndex = 2;
            this.btnNroTres.Text = "3";
            this.btnNroTres.UseVisualStyleBackColor = true;
            this.btnNroTres.Click += new System.EventHandler(this.btnNroTres_Click);
            // 
            // btnNroDos
            // 
            this.btnNroDos.Location = new System.Drawing.Point(65, 18);
            this.btnNroDos.Name = "btnNroDos";
            this.btnNroDos.Size = new System.Drawing.Size(44, 43);
            this.btnNroDos.TabIndex = 1;
            this.btnNroDos.Text = "2";
            this.btnNroDos.UseVisualStyleBackColor = true;
            this.btnNroDos.Click += new System.EventHandler(this.btnNroDos_Click);
            // 
            // btnNroUno
            // 
            this.btnNroUno.Location = new System.Drawing.Point(15, 18);
            this.btnNroUno.Name = "btnNroUno";
            this.btnNroUno.Size = new System.Drawing.Size(44, 43);
            this.btnNroUno.TabIndex = 0;
            this.btnNroUno.Text = "1";
            this.btnNroUno.UseVisualStyleBackColor = true;
            this.btnNroUno.Click += new System.EventHandler(this.btnNroUno_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(216, 242);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(169, 38);
            this.btnSalir.TabIndex = 4;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseMnemonic = false;
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnLlamar
            // 
            this.btnLlamar.Location = new System.Drawing.Point(215, 77);
            this.btnLlamar.Name = "btnLlamar";
            this.btnLlamar.Size = new System.Drawing.Size(170, 43);
            this.btnLlamar.TabIndex = 5;
            this.btnLlamar.Text = "Llamar";
            this.btnLlamar.UseVisualStyleBackColor = true;
            this.btnLlamar.Click += new System.EventHandler(this.btnLlamar_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(215, 126);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(170, 43);
            this.btnLimpiar.TabIndex = 6;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // FrmLlamador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 345);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnLlamar);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.gpbPanel);
            this.Controls.Add(this.cbmFranjas);
            this.Controls.Add(this.txtNroOrigen);
            this.Controls.Add(this.txtNroDestino);
            this.Name = "FrmLlamador";
            this.Text = "FrmLlamador";
            this.gpbPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNroDestino;
        private System.Windows.Forms.TextBox txtNroOrigen;
        private System.Windows.Forms.ComboBox cbmFranjas;
        private System.Windows.Forms.GroupBox gpbPanel;
        private System.Windows.Forms.Button btnNroNumeral;
        private System.Windows.Forms.Button btnNroCero;
        private System.Windows.Forms.Button btnAsterisco;
        private System.Windows.Forms.Button btnNroNueve;
        private System.Windows.Forms.Button btnNroOcho;
        private System.Windows.Forms.Button btnNroSiete;
        private System.Windows.Forms.Button btnNroSeis;
        private System.Windows.Forms.Button btnNroCinco;
        private System.Windows.Forms.Button btnNroCuatro;
        private System.Windows.Forms.Button btnNroTres;
        private System.Windows.Forms.Button btnNroDos;
        private System.Windows.Forms.Button btnNroUno;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnLlamar;
        private System.Windows.Forms.Button btnLimpiar;
    }
}