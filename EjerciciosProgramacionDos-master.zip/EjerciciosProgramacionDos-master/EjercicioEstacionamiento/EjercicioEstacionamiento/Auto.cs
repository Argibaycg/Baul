﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEstacionamiento
{
    class Auto
    {
            private string patente;
            private string marca;
            private int cantidadPuertas;
            private int dniDueño;

            public Auto(string patente, string marca, int cantidadPuertas, int dniDueño) : this(patente, dniDueño)
            {
                this.marca = marca;
                this.cantidadPuertas = cantidadPuertas;
            }

            public Auto(string patente, int dniDueño) : this()
            {
                this.patente = patente;
                this.dniDueño = dniDueño;
            }
            private Auto()
            {
                this.marca = "Dato no ingresado";
                this.cantidadPuertas = -1;
            }

            public string GetInfo()
            {
                StringBuilder unAuto = new StringBuilder();
                unAuto.AppendLine($"Patente: {this.patente}.\n* - * - * - * - * - * ");
                unAuto.AppendLine($"Marca: {this.marca}.\n* - * - * - * - * - * ");
                if (this.cantidadPuertas == -1)
                {
                    unAuto.AppendLine($"Cantidad de Puertas: Dato no ingresado.\n* - * - * - * - * - * ");
                }
                else
                {
                    unAuto.AppendLine($"Cantidad de Puertas: {this.cantidadPuertas}.\n* - * - * - * - * - * ");
                }

                unAuto.AppendLine($"DNI: {this.dniDueño}.\n* - * - * - * - * - * ");

                return unAuto.ToString();


            }

            public void SetInfo(int cantidadPuertas)
            {
                this.cantidadPuertas = cantidadPuertas;
            }
            public void SetInfo(string marca)
            {
                this.marca = marca;
            }
            public void SetInfo(string marca, int cantidadPuertas)
            {
                this.SetInfo(marca);
                this.SetInfo(cantidadPuertas);
            }

            public static bool operator ==(Auto autoA, Auto autoB)
            {
                return (autoA.patente == autoB.patente);
            }

            public static bool operator !=(Auto autoA, Auto autoB)
            {
                return !(autoA.patente == autoB.patente);
            }
        }
}
