﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CentralitaHerencia;
using System.Collections.Generic;

namespace TestCentralita
{
    [TestClass]
    public class TestCentralita
    {
        [TestMethod]
        public void TestCentralitaInstanciada()
        {
            //Arange
            Centralita centralita;
            //Act
            centralita = new Centralita();
            //Assert
            Assert.IsNotNull(centralita.Llamadas);
        }

        [TestMethod]
        [ExpectedException(typeof(CentralitaException))]
        public void TestCentralitaExceptionLocal()
        {
            //Arange
            Centralita c = new Centralita("Fede Center");
            Local l1 = new Local("Bernal", 30, "Rosario", 2.65f);
            Local l2 = new Local("Bernal", 45, "Rosario", 1.99f);
            //Act
            c += l1;
            c += l2;
            //Assert
        }

        [TestMethod]
        [ExpectedException(typeof(CentralitaException))]
        public void TestCentralitaExceptionProvincial()
        {
            //Arange
            Centralita c = new Centralita("Fede Center");
            Provincial l1 = new Provincial("Morón", Provincial.Franja.Franja_3, 10, "Bernal");
            Provincial l2 = new Provincial("Morón", Provincial.Franja.Franja_1, 21, "Bernal");
            //Act
            c += l1;
            c += l2;
            //Assert
        }

        [TestMethod]
        public void TestCentralitaComparaLocalProvincial()
        {
            //Arange
            Centralita c = new Centralita("Fede Center");
            Provincial l1 = new Provincial("Bernal", Provincial.Franja.Franja_3, 10, "Rosario");
            Provincial l2 = new Provincial("Bernal", Provincial.Franja.Franja_1, 21, "Rosario");
            Local l3 = new Local("Bernal", 30, "Rosario", 2.65f);
            Local l4 = new Local("Bernal", 45, "Rosario", 1.99f);
            //Act
            bool igualUno = (l1 == l2);
            bool igualDos = (l3 == l4);
            bool igualTres = (l1 == l3);
            bool igualCuatro = (l2 == l4);
            //Assert
            Assert.IsTrue(igualUno == igualDos);
            //Assert.IsTrue(igualDos);
            Assert.IsFalse(igualTres);
            Assert.IsFalse(igualCuatro);
        }
    }
}
