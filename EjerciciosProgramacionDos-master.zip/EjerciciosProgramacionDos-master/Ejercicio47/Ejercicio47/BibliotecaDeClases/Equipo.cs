﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaDeClases
{
    public abstract class Equipo
    {
        public string nombre;
        public DateTime fechaCreacion;

        public static bool operator ==(Equipo equipoUno, Equipo equipoDos)
        {
           if(equipoUno.nombre == equipoDos.nombre && equipoUno.fechaCreacion == equipoDos.fechaCreacion)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(Equipo equipoUno, Equipo equipoDos)
        {
            return !(equipoUno == equipoDos);
        }

        public string Ficha(Equipo equipo) 
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"{this.nombre} fundado el {this.fechaCreacion}\n");

            return sb.ToString();
        }
    }
}
