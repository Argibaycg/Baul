﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Excepciones;

namespace ClasesAbstractas
{
    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;
        private string nombre;

        #region Propiedades
        /// <summary>
        /// Propiedad  de lectoescritura que valida el nombre
        /// </summary>
        private string Nombre { get { return this.nombre; } set { this.nombre = ValidarNombreApellido(value); } }
        /// <summary>
        /// Propiedad  de lectoescritura que valida el apellido
        /// </summary>
        public string Apellido { get { return this.apellido; } set { this.apellido = ValidarNombreApellido(value); } }
        /// <summary>
        /// Propiedad de lectoescritura para la nacionalidad
        /// </summary>
        public ENacionalidad Nacionalidad { get { return this.nacionalidad; } set { this.nacionalidad = value; } }
        /// <summary>
        /// Propiedad  de lectoescritura que valida el DNI
        /// </summary>
        public int DNI { get { return this.dni; } set { this.dni = ValidarDni(this.nacionalidad, value); } }
        /// <summary>
        /// Propiedad  de escritura que valida el DNI
        /// </summary>
        private string StringToDni { set { this.dni = ValidarDni(this.nacionalidad, value); } }
        #endregion


        #region Constructores
        /// <summary>
        /// Constructor por defecto
        /// </summary>
        public Persona() : this(string.Empty, string.Empty, default(ENacionalidad))
        {
            this.dni = default;
        }

        /// <summary>
        /// Constructor que recibe nombre, apellido y nacionalidad 
        /// </summary>
        /// <param name="nombre">Nombre de la persona</param>
        /// <param name="apellido">Apellido de la persona</param>
        /// <param name="nacionalidad">Nacionalidad de la persona</param>
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.Nombre = ValidarNombreApellido(nombre);
            this.Apellido = ValidarNombreApellido(apellido);
            this.Nacionalidad = nacionalidad;
        }

        /// <summary>
        /// Constructor que recibe nombre, apellido, dni y nacionalidad 
        /// </summary>
        /// <param name="nombre">Nombre de la persona</param>
        /// <param name="apellido">Apellido de la persona</param>
        /// <param name="dni">DNI de la persona como entero</param>
        /// <param name="nacionalidad">Nacionalidad de la persona</param>
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.DNI = dni;
        }

        /// <summary>
        /// Constructor que recibe nombre, apellido, dni y nacionalidad 
        /// </summary>
        /// <param name="nombre">Nombre de la persona</param>
        /// <param name="apellido">Apellido de la persona</param>
        /// <param name="dni">DNI de la persona como string</param>
        /// <param name="nacionalidad">Nacionalidad de la persona</param>
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.StringToDni = dni;
        }

        #endregion

        #region Validaciones
        /// <summary>
        /// Validacion de DNI
        /// </summary>
        /// <param name="nacionalidad">Nacionalidad</param>
        /// <param name="dato">DNI</param>
        /// <returns>Retorna el parametro dato o lanza NacionalidadInvalidaException</returns>
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {

            switch (nacionalidad)
            {
                case ENacionalidad.Argentino:
                    if (dato >= 1 && dato <= 89999999)
                    {
                        return dato;
                    }
                    break;
                case ENacionalidad.Extranjero:
                    if (dato >= 90000000 && dato <= 99999999)
                    {
                        return dato;
                    }
                    break;
            }
            throw new NacionalidadInvalidaException();
        }

        /// <summary>
        /// Validacion de DNI
        /// </summary>
        /// <param name="nacionalidad">Nacionalidad</param>
        /// <param name="dato">Dato</param>
        /// <returns>Retorna el dato llamando a la validacion con otro tipo de dato o lanza DNIInvalidoException</returns>
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int datoInt = default;
            Regex reg = new Regex(@"^[0-9]+$");
                if (int.TryParse(dato, out datoInt) && dato.Length <= 8 && reg.IsMatch(dato))
                {
                    return ValidarDni(nacionalidad, datoInt);
                }
                else
                {
                    throw new DniInvalidoException();
                }
        }

        /// <summary>
        /// Valida el nombre y Apellido
        /// </summary>
        /// <param name="dato">Dato a validar</param>
        /// <returns>Retorna el dato validado o un string vacio</returns>
        private string ValidarNombreApellido(string dato)
        {
            string auxDato = string.Empty;
            Regex rx = new Regex(@"^[A-Z][a-z ]+$");
            if (rx.IsMatch(dato))
            {
                auxDato = dato;
            }
            return auxDato;
        }

        #endregion

        #region Metodos
        /// <summary>
        /// Sobrecarga del metodo ToString
        /// </summary>
        /// <returns>Retorna los datos de la Persona</returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("NOMBRE COMPLETO: {0}, {1}\r\n", this.Apellido, this.Nombre);
            sb.AppendFormat("NACIONALIDAD: {0}\n", this.Nacionalidad.ToString());

            return sb.ToString();
        }
        #endregion
    }
}
