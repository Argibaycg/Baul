﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio42
{
    class MiClase
    {

        public MiClase()
        {
            try
            {
                MiClase cosaDeMiClase = new MiClase();

            }
            catch (UnaExcepcion miExcepcion)
            {
                throw miExcepcion;
            }

        }

        public MiClase(string cosa) : this()
        {
            try
            {

            }
            catch (DivideByZeroException)
            {

                throw new DivideByZeroException();
            }
        }
        public static bool MetodoDeMiClase()
        {
            throw new DivideByZeroException();
        }


    }
}
