﻿using CentralitaHerencia;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmMenu
{
    public partial class FrmLlamador : Form
    {

        private Centralita centralita;

        public FrmLlamador(Centralita centralita)
        {
            InitializeComponent();
            this.centralita = centralita;
            // Carga 
            cbmFranjas.DataSource = Enum.GetValues(typeof(Provincial.Franja));
        }


        public Centralita Centralita { get { return this.centralita; } }

        private void txtNroDestino_TextChanged(object sender, EventArgs e)
        {
            if (txtNroDestino.Text.StartsWith("#"))
            {
                cbmFranjas.Enabled = true;
            }
            else
            {
                cbmFranjas.Enabled = false;
            }
        }

        private void btnNroNumeral_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "#";
        }

        private void txtNroDestino_Leave(object sender, EventArgs e)
        {
            if (txtNroDestino.Text.Contains("Nro Destino"))
            {
                txtNroDestino.Text = "";
            }
        }

        private void btnNroUno_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "1";
        }

        private void btnNroDos_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "2";
        }

        private void btnNroTres_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "3";
        }

        private void btnNroCuatro_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "4";
        }

        private void btnNroCinco_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "5";
        }

        private void btnNroSeis_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "6";
        }

        private void btnNroSiete_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "7";
        }

        private void btnNroOcho_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "8";
        }

        private void btnNroNueve_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "9";
        }

        private void btnNroCero_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "0";
        }

        private void btnAsterisco_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text += "*";
        }

        private void btnLlamar_Click(object sender, EventArgs e)
        {
            int duracion = default;
            float costo = default;

            Random rnd = new Random();
            duracion = rnd.Next(1, 50);
            //costo = rnd.Next(0.5, 5.6);

            if (txtNroDestino.Text == "Nro Destino" || txtNroOrigen.Text == "Nro Origen")
                MessageBox.Show("Numero Origen/Destino invalido");
            else
            {
                try
                {
                    if (txtNroDestino.Text.StartsWith("#"))
                    {
                        //lectura
                        Provincial.Franja franjas;
                        Enum.TryParse<Provincial.Franja>(cbmFranjas.SelectedValue.ToString(), out franjas);

                        this.centralita = centralita + new Provincial(txtNroOrigen.Text, franjas, rnd.Next(1, 50), txtNroDestino.Text);
                    }
                    else
                    {
                        this.centralita = centralita + new Local(txtNroOrigen.Text, rnd.Next(1, 50), txtNroDestino.Text, (float)rnd.NextDouble() * 5.6f);
                    }
                }
                catch (CentralitaException noSePuedeAgregarLLamadaException)
                {
                    MessageBox.Show(noSePuedeAgregarLLamadaException.Message);
                }
            }
        }
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNroDestino.Text = "Nro Destino";
            txtNroOrigen.Text = "Nro Origen";
            cbmFranjas.Text = "Franja";
            txtNroDestino.Focus();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
